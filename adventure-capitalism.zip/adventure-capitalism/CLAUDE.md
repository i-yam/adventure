# CLAUDE.md

This repo holds the learning materials for Adventure Capitalism, a twelve-class entrepreneurship course. The pages live on GitHub and students read them there.

Write for the one student in the room who will actually build something that matters. You do not know which one it is. Some of the people reading these pages will start real companies, hire real people, and make or lose real money. Assume generational talent is sitting in the room and write up to it, not down to the median. The job is not to help anyone pass a course. It is to hand them the mental models founders actually use, in a voice they will still trust at two in the morning when the thing is on fire.

The bar is the best startup writing on the internet. Y Combinator's Startup Library and the a16z blog set the standard for how founders get taught: plain, direct, evidence over theory, no filler, no hype. Meet that bar. When we teach something those sources already nailed, we do not blend it into a gray paraphrase. We teach it in our own voice and send the student to the original.

You are writing for a nineteen-year-old who is smart, busy, and allergic to being talked down to. Every rule below exists to keep that person reading.

Read this whole file before you write a single page. The voice section is not decoration. A page that gets the facts right and the voice wrong gets rewritten.

---

## What the course is

Adventure Capitalism. Twelve classes. Students build a startup idea across the term and pitch it. The reading draws on founder-facing books (Horowitz, *The Hard Thing About Hard Things*; Strebulaev and Dang, *The Venture Mindset*; Christian and Griffiths, *Algorithms to Live By*) and on the intellectual history behind why any of this exists at all (Weber on the profit ethic, Shorto on where liberal markets came from).

Every fourth class is a shark tank. Students pitch, the room pushes back, ideas survive or die. Classes 4, 8, and 12 are pitch days. The nine classes in between are build days.

Everything is hands-on. If a page could be a lecture or an activity, make it an activity. Passive reading is the fallback, not the plan.

---

## The canon

Two libraries carry this field, and the course stands on both. Read them so your pages agree with them, and so you know when you are repeating them.

Y Combinator's Startup Library is the closest thing startups have to a textbook. The root is https://www.ycombinator.com/library. The pieces this course returns to most:

- YC's Essential Startup Advice: https://www.ycombinator.com/library/4D-yc-s-essential-startup-advice
- Paul Graham, How to Get Startup Ideas: https://www.ycombinator.com/library/8z-how-to-get-startup-ideas
- Paul Graham, Do Things That Don't Scale: https://www.ycombinator.com/library/96-do-things-that-don-t-scale

The a16z blog is where the venture side argues its case, at https://a16z.com. The pieces that matter most here:

- Marc Andreessen, The Only Thing That Matters (2007), the essay that turned "product/market fit" into the phrase every founder repeats: https://pmarchive.com/guide_to_startups_part4.html
- a16z, Product-User Fit Comes Before Product-Market Fit (2023): https://a16z.com/product-user-fit-comes-before-product-market-fit/
- Marc Andreessen, Why Software Is Eating the World, and Andrew Chen on growth and network effects, both findable from the a16z blog root, are worth pointing students to when a page touches those subjects.

Two rules for the canon. First, when a page teaches something the canon owns, finding a problem worth solving, launching before you feel ready, doing things that don't scale, product/market fit, teach it in our voice and our activity, then link the primary source so the student can read the founder's own words. The link lives in the page's reading block, the small labeled slot at the foot of the core track (see the House HTML style). Never a wall of quotation. Our value is the concrete task and the voice, not a book report on someone else's essay.

Second, YC and a16z do not always agree, and the disagreement is the lesson. YC tells a founder to launch now and talk to users. a16z tells them the market is the only thing that matters and a great team in a dead market still loses. Both are right, and a student who has only heard one house is half-educated. Show both sides and let them argue.

### The reading map

One Paul Graham essay per build class, placed so the reading and the pitch it feeds point the same way. The pitch days (4, 8, 12) get no new reading, the students pitch. Each essay is the reading-block link on its class page.

Cycle 1, find a real problem, into the Class 4 rough-idea pitch:

- Class 1, How to Get Startup Ideas (2012): https://www.ycombinator.com/library/8z-how-to-get-startup-ideas
- Class 2, Schlep Blindness (2012), the best ideas hide behind work people avoid: https://paulgraham.com/schlep.html
- Class 3, Startup = Growth (2012), what separates a startup from a small business: https://paulgraham.com/growth.html

Cycle 2, test it and get users, into the Class 8 evidence pitch:

- Class 5, Do Things That Don't Scale (2013): https://www.ycombinator.com/library/96-do-things-that-don-t-scale
- Class 6, The 18 Mistakes That Kill Startups (2006), number one is not making something people want: https://paulgraham.com/startupmistakes.html
- Class 7, Before the Startup (2014), startups are counterintuitive, so stop trusting your instincts: https://paulgraham.com/before.html

Cycle 3, survive and raise, into the Class 12 real pitch:

- Class 9, Default Alive or Default Dead? (2015), the one question about your own runway: https://www.paulgraham.com/aord.html
- Class 10, How to Raise Money (2013), the mechanics: https://paulgraham.com/fr.html
- Class 11, How to Convince Investors (2013), reads like a rubric for the final pitch: https://paulgraham.com/convince.html

For the Class 12 pitch, How to Present to Investors is the natural companion re-read. Optional deep-dive shelf, off the core track: Why to Not Not Start a Startup (2007), Frighteningly Ambitious Startup Ideas (2012), Ramen Profitable (2009), Relentlessly Resourceful (2009). All of Graham's essays are indexed at https://paulgraham.com/articles.html, and most are mirrored in the YC library, so if a deep link ever 404s the index is the fix.

Graham writes from inside YC, so his frame is software and venture funding, grow fast and raise money. Many students will build good businesses that are not venture startups, and for them that advice is wrong. Teach the essay, then say plainly where it stops applying. That is the same disagreement move as above.

---

## The pitch-day arc

The three shark tanks are not the same event three times. The stakes climb.

Class 4: the rough idea. Students pitch a problem and a guess at a solution. Nobody has customers yet. The room is looking for whether the problem is real.

Class 8: the tested idea. Students have talked to real people and have something to show for it. The room is looking for evidence, not enthusiasm.

Class 12: the real pitch. Students pitch as if money were on the table. The room acts like it is.

Build days feed the next shark tank. Classes 1 to 3 build toward the class-4 pitch, 5 to 7 toward class 8, 9 to 11 toward class 12. Write every build-day page knowing which pitch it serves.

---

## The syllabus

The twelve classes run in three blocks, each named for the funding stage it mimics and each ending in a shark tank. The block spine is the promise the founder is trying to make good on.

Block 1, Pre-seed, "Make something people want." Classes 1 to 4. Find a problem worth solving and learn to tell its story.

Block 2, Seed, "Prove they want it." Classes 5 to 8. Turn a validated problem into the minimum thing that shows product/market fit.

Block 3, Series A, "Prove you can grow it." Classes 9 to 12. Build the go-to-market engine and the org that scales a working product into a business.

Inside each block the shape repeats. One class lays the core framework, one or two widen the lens, one packages the work into a pitch, and the fourth is the shark tank. The deck built in Block 1 gets reloaded at every later pitch, not rebuilt. Each class line below names the concepts it carries and the essay it reads; the URLs live in the reading map above, the definitions live in the two toolkits below.

### Block 1 · Pre-seed

Class 1, Customer discovery. Get outside the building. The customer development loop (discovery, validation, and the pivot when the evidence says so), Build-Measure-Learn, and problem framing: what problem, for whom, why it matters. The block's north star is "make something people want." Interview craft is the hands-on core: open questions over closed ones, the idea held as a hypothesis you are trying to disprove, dissent invited instead of the consensus theater where everyone politely agrees your idea is great. Fieldwork starts here and runs the whole block. Reads How to Get Startup Ideas.

Class 2, The venture mindset. Why discovery-driven betting is how you find winners. What venture capital is and why it drives innovation. Probabilistic investing: the power law, Pareto, home runs matter and strikeouts do not, and great things take time. Explore before you exploit. Optimal stopping and the 37% rule for when to stop searching, whether the search is for a problem or a co-founder. Reasoning from little data with Bayes. Overfitting, the danger of over-tuning to a few loud users. Failure as a feature, and nobody cares about your excuses. The origin story folds in here, or becomes pre-reading if the class runs long: Amsterdam and the VOC, Weber's calling, Shorto's Calvinist paradox and gedogen, the question of why the founder archetype exists at all. Reads Schlep Blindness.

Class 3, The pitch. Turning discovery into a story. The structural parts of a deck that works: problem, who has it, evidence, the hypothesis, the team, why now. Storytelling and the unique selling proposition. Computational kindness applied to a deck, minimize the audience's mental work with clear asks, sensible defaults, and stated constraints. This framework is reused and reloaded at every later shark tank. Reads Startup = Growth.

Class 4, Shark Tank #1. The problem pitch. No new materials, they pitch.

### Block 2 · Seed

Class 5, Product/market fit. Why a technology is not a product. Paper prototyping and the minimum viable product. What PMF actually is, how you would know you have it, and the signals that you do not. Pivot as a mode of survival, double down or quit. Milestone-based building, where you fund the next stage only on a hit. The Business Model Canvas as the mapping tool, with the value proposition at its center. Reads Do Things That Don't Scale.

Class 6, Solving hard problems. Decision tools for when there is no playbook. There are no easy answers, the Struggle is the job. Lead bullets, not silver bullets. Relaxation, loosening a constraint on purpose and solving the easier problem first. Randomness, sampling instead of surveying and injecting noise to escape a local optimum. Scheduling and context-switching, where the right order depends on the metric you chose to optimize, and thrashing is the failure mode. Caching, deciding what stays top of mind and what moves to shared docs. The foundations of price and value: elasticity, supply and demand, branding. Reads The 18 Mistakes That Kill Startups.

Class 7, The seed pitch. Reloading the deck with traction. The full nine-part structure: problem, market and TAM, solution, unit economics, team, ask, roadmap, MVP, competitive advantage. Fundraising as a market of one, conviction over consensus. Worked example, the Yelp deck's sequence, market to product to engagement to unit economics to financials to ask. Reads Before the Startup.

Class 8, Shark Tank #2. The seed pitch. No new materials.

### Block 3 · Series A

Class 9, Go-to-market and unit economics. The growth engine. CAC, LTV, contribution margin. Distribution channels and partnerships, data-driven marketing. Pricing revisited, elasticity and branding as levers on LTV. Channels read as explore then exploit: test many, concentrate, double down, with a Bayesian eye on thin channel data. Overfitting returns as Goodhart's law, any metric degrades once it becomes the target, so beware the single north-star. The Yelp case runs live: the contribution-margin ramp, 269% advertiser ROI, cohort growth, the Philadelphia flywheel of content to traffic to monetization, and the long-term target model. Reads Default Alive or Default Dead?.

Class 10, Building and leading the team. Who runs the engine. Managing small teams, discipline against creativity, motivation and empathy. Managing your own psychology, the CEO's hardest job. Wartime CEO against peacetime CEO. Radical transparency, tell it like it is. Hire for strength, not for the absence of weakness. The right kind of ambition, for the company over the self. One-on-ones belong to the report. Courage over intelligence when both sides of a call have a case. Management debt. How layoffs and firings define the culture. People, then products, then profits. Reads How to Raise Money.

Class 11, Incentives and scale load. Keeping the engine aligned. Make the pie bigger through ownership. Mechanism design, arranging things so self-interest produces the outcome you want, and watching for races to the bottom. Backpressure, borrowed from TCP: do not overload people or systems, and spot buffer bloat, the backlog that hides how overwhelmed things really are. Context-switching and caching again, now at org scale. Game theory, you cannot always win a bad game, but you can sometimes change its rules. Reads How to Convince Investors.

Class 12, Shark Tank #3. The Series A pitch. Money is on the table and the room acts like it.

### The decision-tools toolkit

From Algorithms to Live By. These recur across the course, so pull the exact framing from here when a class reaches for one.

- Optimal stopping, the 37% rule. For sequential choices you cannot easily reverse (a hire, a co-founder, an office, when to close a raise), spend the first 37% of the search building a baseline, then take the first option that beats everything seen so far. Knowing when to stop looking is its own skill, separate from judging options well.
- Explore vs exploit. Early, with a long runway ahead, favor exploration: test many markets, channels, and features. As signal builds, shift toward exploiting what works. The value of exploring shrinks as the horizon shortens, which is why late pivots cost far more than early ones.
- Overfitting. More tuning is not always better. Over-fitting to a few loud customers, one north-star metric, or last quarter yields a strategy that fits the past and generalizes badly. Simpler heuristics often survive contact with reality better, and any metric decays once it becomes the target.
- Scheduling and context-switching. The right task order depends entirely on the metric you are optimizing; minimizing lateness, dropped balls, or weighted importance each give a different order, so pick the metric on purpose. Guard against thrashing, switching so often that all the capacity goes to switching and none to the work.
- Caching. You cannot hold everything top of mind. Decide what stays close (in your head, your tools, shared team docs) and let the rest live in slower storage you fetch on demand. Least-recently-used is a surprisingly good rule for what to drop.
- Bayes, predicting from little data. Founders forecast constantly from tiny samples, and one data point means different things depending on the prior you bring. Make priors explicit and update in proportion to the evidence, rather than overreacting to one good week or one lost deal.
- Relaxation. When a problem is truly intractable (the perfect roadmap, org, or price), loosen a constraint on purpose and solve the easier version first. A good answer to a slightly relaxed problem beats a frozen search for a perfect one, as long as you relax on purpose and keep moving.
- Randomness. Stuck in a local optimum, or facing something too big to analyze exhaustively, sample instead of surveying and inject a little noise to jolt out of the rut. Not every decision earns exhaustive optimization.
- Game theory and mechanism design. You cannot always win a bad game, but you can sometimes change its rules. Design incentives (comp, equity, culture, customer pricing) so self-interested moves produce the outcome you want, and watch for races to the bottom where everyone's rational choices leave everyone worse off.
- Backpressure. Borrowed from TCP: acknowledge receipt and back off when a channel is swamped, instead of hammering it. In practice, do not overload people or systems, and spot buffer bloat, the giant backlog that quietly adds latency and hides how overwhelmed things really are.
- Computational kindness. When you ask something of a teammate, customer, or investor, minimize the mental work you impose. Offer constraints and defaults over open-ended optionality, "here are three times that work" beats "when are you free?". Lowering others' decision cost is underrated leadership.

### The founder-psychology toolkit

From Horowitz, The Hard Thing About Hard Things. Mostly Block 3, the management and morale material.

- There are no easy answers, embrace the Struggle. The hardest problems in building a company have no formula. The honest lesson is that founding is brutal and lonely, and surviving the emotional low is itself the skill.
- Managing your own psychology is the CEO's hardest job. Keeping your own mind intact under relentless pressure matters more than strategy or product. Get problems out of your head and onto paper, find peers who have done it, and focus on where you are going, not the wall you might hit.
- Wartime CEO vs peacetime CEO. Growing a lead and fighting for survival need opposite instincts, one follows protocol and expands, the other breaks rules to survive. Read which mode the company is actually in and adapt, instead of leading the same way always.
- Tell it like it is, radical transparency. Share the bad news, not only the good. People handle hard truths, and surfacing problems openly means everyone helps solve them. Build a culture that rewards raising problems over hiding them.
- People, products, profits, in that order. If the people are not taken care of, nothing else holds. In bad times, weak cultures collapse into politics.
- Lead bullets, not silver bullets. When a competitor's product is simply better, no positioning trick saves you, you go build a better product. Resist the seductive shortcut and do the hard work.
- Hire for strength, not lack of weakness. Do not pick the candidate with no obvious flaws, pick the one with a standout strength that matters for the role. Every strong person has weaknesses; the question is whether the strength is decisive.
- Beware management debt. Like technical debt, expedient people-decisions (a counteroffer to retain someone, two people sharing one job, skipping performance management) feel cheap now and compound into real costs later.
- Courage over intelligence. The hardest calls have strong arguments on both sides. What separates good founders is not finding the right answer, it is the courage to decide and own it with incomplete information.
- Nobody cares, run your company. When things go wrong, the market, competitors, and reality do not care about your reasons. Stop hunting for someone to blame and run the company.
- Layoffs and firings define your culture. Do them fast, be honest about why, make managers face their own people, and stay present. How you treat people on the way out shapes how the survivors trust you.
- The right kind of ambition. Hire executives whose ambition is for the company and the mission, not mainly for themselves. It shows in how they build teams and share credit.
- One-on-ones belong to the employee. The best information flows up when the report drives the meeting and does most of the talking. It is a key channel for catching problems early.
- A market of one. Raising privately, you do not need consensus, you need one investor with conviction to say yes. Aim the pitch at that person.

---

## Design principles

Seven of them. They are in tension sometimes. When they conflict, accessible and hands-on win.

Accessible. Concept before technical, real-world example before formula. A student meets the idea as a thing that happened to a person before they meet it as an abstraction. Nobody learns the definition first.

Learning by doing. Minimal frontal lecture, maximum hands-on. The default page is an activity with just enough setup to start it. If you find yourself explaining for three paragraphs before the student does anything, cut two of them.

Asymmetric depth. Every topic has a core track anyone can follow and optional deep-dive sections on the same page. The curious student goes further. The main track never gets scarier because the deep dives exist. A deep dive is folded away, clearly marked, and skippable without penalty.

Sticky. Students leave with mental models they use, not answers they forget. Ask yourself: six months from now, in a real decision, will this page fire in their head? If not, it is trivia.

Gen-AI literate. Some tasks are meant to be done without AI, because the struggle is the point. Others are meant to be done with AI, and we show how. Every task says which it is and why. See the AI policy below.

Personalizable. The tag system lets a student orient by interest, technical comfort, and time. A student with forty-five minutes and no code background can find their path without reading everything.

---

## The tag system

Every page carries the same fixed set of tags. Students filter by them. Do not invent new values without adding them here first.

```
type:     build | pitch
interest: product | customers | fundraising | sales | ops | finance | mindset   (a page can carry more than one)
comfort:  no-code | some-code | builder
time:     15min | 45min | deep
track:    core | deep-dive
ai:       off | on
```

Interest says what area of building the page serves. Comfort says how much technical fluency it assumes; most of the course is no-code, and that is deliberate. Time is an honest estimate of how long the work takes, not how long the reading takes. Track marks whether a section is main-line or optional depth. AI marks the policy for that task.

In an HTML page the tags live in two places, kept in sync. A machine-readable line in the head for future filtering:

```html
<meta name="ac:tags" content="interest=customers; comfort=no-code; time=45min; track=core; ai=off">
```

and the visible mono tag rail the student actually reads (see the House HTML style below).

A student should be able to say "show me the forty-five-minute no-code customer work" and get a clean, coherent path. Tag with that student in mind.

---

## Voice

This is the part that gets pages rewritten. Read it twice.

The models are Dovlatov, Chekhov, and Bukowski. Dry, precise, observant, rooted in the ordinary. Say exactly what you mean, no more, and make it land.

From Dovlatov, take the dry irony and the precise detail. The humor comes from noticing the right thing, never from reaching for a joke. From Chekhov, take the economy. One good detail does the work of a paragraph. Show the reality, then stop; do not explain what it means. The student can figure it out. From Bukowski, take the bluntness. Say the uncomfortable thing plainly. Do not dress up an ordinary observation in academic clothes.

In practice:

Start concrete. Never open with a definition. Open with a thing, a person, a number, a situation. Let the abstraction show up once the student has something in their hand. "Ninety percent of the pitches in this room will fail. Let's talk about the ten percent" beats "This module introduces the fundamentals of pitching."

Short, declarative sentences. Be economical. Long sentences build context. Short ones land. The rhythm carries the argument.

Direct address. Talk to the student, not about the topic.

Bold is plain. The stakes here are real and you are allowed to say so, but boldness is a clear claim in plain words, not a raised voice. Andreessen did not hedge "the only thing that matters is getting to product/market fit." He said it once, flat, and moved on. Copy that. State the hard thing plainly and let it sit there. Hype is the opposite of bold; it is what people reach for when they do not trust the claim to stand on its own.

Let humor come from the observation. "The pegs do not care where the ball lands. You, presumably, do." That is the whole voice in two sentences.

Cut the throat-clearing. No "In this section, we will." No "As we have seen." Get to the thing.

### Hard constraints

These are not preferences. Break one and the page is wrong.

No em-dashes. None. Use a comma, a period, or a new sentence.

No AI jargon. These words are banned outright: nuance, nuanced, tapestry, paramount, testament, delving, navigating, crucial, vital, overarching.

No lists in student-facing prose. Write in paragraphs. No bulleted fragments, no bold-word prefixes, no invented section headers inside a flowing explanation. (This rule is about the pages students read. This config file uses lists because it is instructions, not a lesson.)

No neat conclusions. Stop the moment the last real point is made. No wrap-up, no summary, no moral stated out loud. Leave it unresolved. Real life does not tie off.

No banned phrasings. Never write "This is not X, this is Y" or any version of it. Never open a closer with "Ultimately," "In conclusion," "To sum up," or "At its core."

### University boundaries

The humor is dry and observational, not crude. The voice is direct, not aggressive. A student should finish a page feeling respected and awake, not lectured and not slapped. Bukowski's honesty, not his bar fights.

### Before you publish, check

- Does it open with something concrete?
- Any em-dashes? Any banned words? Kill them.
- Any lists hiding in the prose? Turn them into sentences.
- Does the last line just stop, or does it summarize? If it summarizes, cut the last paragraph.
- Read the first line and the last line back to back. If they sound like a textbook, start over.

---

## Gen-AI policy

The course takes a position: AI is a tool students will use for the rest of their lives, so pretending it does not exist is malpractice. But some skills only form under friction, and AI removes the friction. So each task is marked, and the mark is honest about why.

An AI-off task carries `ai=off` and opens with the solid marker `[ NO AI ] DO THIS ONE YOURSELF`, then one sentence on why, in the voice. Customer interviews, first drafts of a pitch, the moment of deciding what problem to chase. The struggle is the skill. Outsourcing it means learning nothing.

An AI-on task carries `ai=on` and opens with the outline marker `[ AI OK ] USE THE TOOLS`, then a short, worked example of a good prompt and what to do with the output. Market sizing, competitor scans, turning a messy interview transcript into themes. Show the student how a founder actually uses this, including where the model lies and how they would catch it.

Never leave a task unmarked. An unmarked task tells the student the author did not think about it, and they will notice.

---

## House HTML style

Every page in this repo is a single HTML file that links `style.css` and looks like `class-01/index.html`. Each class is its own folder (`class-NN/`) holding one `index.html`, so the stylesheet link is one level up: `../style.css`. Do not invent a second look. Do not restyle per page. The sameness is the point. A student should know they are still inside Adventure Capitalism without reading the masthead.

The look, in one breath. Modernist, Swiss grid, light theme, near-black text on warm paper white, one electric cobalt accent used with restraint. Sans-serif throughout. The signature is the oversized class number. Everything else stays quiet so that number and the accent can land.

The accent (`--accent`, #1B2CE8) appears in exactly four places and nowhere else: the giant class number, text links, the structural rules under the class header, and the AI markers. Reach for it a fifth time and you have already lost the design.

### Source of truth

The full stylesheet is `style.css` at the repo root. Every page links it and never redefines a token inline. To start a new page, copy `_template.html`. The tokens, fonts, and markup below are everything you need to author a page; the exact CSS rules live in `style.css` so they are defined once and cannot drift.

### Fonts

Three families, three jobs. Load them in every page head, before `style.css`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@500;600;800;900&family=Public+Sans:ital,wght@0,400;0,500;0,700;1,400&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../style.css">
```

The `../` is because each page lives in its own `class-NN/` folder while `style.css` sits at the repo root. Archivo at 900 is display: the headline and the class number. Public Sans is body. Space Mono is every piece of metadata, the kicker, the tag rail, the AI markers, the deep-dive toggle. Metadata in mono is what makes the tag system read as data instead of decoration. Use the `mono` class to get it.

### Tokens

Defined in `style.css`. Do not override them per page.

```
--paper      #F7F6F3   page background, warm but bright, not cream
--paper-pure #FFFFFF   reserved for rare pure-white fields
--ink        #141414   text
--ink-soft   #57574F   secondary text, captions, deep-dive body
--accent     #1B2CE8   cobalt, the only color, four uses only
--accent-deep#1220A8   link hover
--rule       #161616   heavy 2px structural rules
--hairline   #D9D8D1   light 1px separators
--measure    37rem     max line length for body, do not widen
--rail       9rem      width of the left label rail
```

### Type scale

The headline and the class number use `clamp`, so they shrink on phones with no extra breakpoint. Body sits at a comfortable reading size. The measure caps line length. Long headlines are fine, they wrap; keep them concrete, not clever.

### Components

Build every page from these blocks, in this order. `_template.html` is the full skeleton. The blocks that carry meaning:

Masthead. Course name left, course descriptor right. The accent dot in the wordmark is the only color here.

```html
<header class="masthead">
  <div class="wrap">
    <div class="brand">ADVENTURE<span class="dot">.</span>CAPITALISM</div>
    <div class="meta mono">12 CLASSES / 3 SHARK TANKS</div>
  </div>
</header>
```

Class header. The signature. Kicker in mono announces the class, the concrete headline in Archivo, the giant number on the right. The number equals the class. It carries `aria-hidden` because the kicker already names the class for a screen reader.

```html
<div class="classhead">
  <div>
    <div class="kicker mono">CLASS 01 · BUILD · FINDING A PROBLEM</div>
    <h1>Concrete headline goes here</h1>
  </div>
  <div class="classnum" aria-hidden="true">01</div>
</div>
```

On a pitch day the kicker reads `CLASS 04 · PITCH · SHARK TANK`.

Tag rail. The tag system, made visible. Same vocabulary as the meta tag. Mono, uppercase, slash-separated. `FEEDS` points at the pitch this build serves.

```html
<div class="tags mono">
  <span><b>INTEREST</b> customers</span>
  <span class="sep">/</span>
  <span><b>COMFORT</b> no-code</span>
  <span class="sep">/</span>
  <span><b>TIME</b> 45min</span>
  <span class="sep">/</span>
  <span><b>TRACK</b> core</span>
  <span class="sep">/</span>
  <span><b>FEEDS</b> class 04 pitch</span>
</div>
```

Body. A two-column grid. A narrow left rail holds a running label naming the section. The right column holds the prose, capped at the measure. The first paragraph takes `.lead`.

```html
<div class="content">
  <aside class="rail"><div class="rail-label mono">The<br>brief</div></aside>
  <div class="body">
    <p class="lead">Open concrete.</p>
    <p>Short sentences.</p>
    ...
  </div>
</div>
```

The work block. Where the activity lives, inside `.body`. A mono label, then the AI marker, then the task, then an optional `.why` note in the accent-bordered aside. The marker is not decoration, it encodes the policy. `aitag off` is a solid black block for `[ NO AI ]`. `aitag on` is a cobalt outline for `[ AI OK ]`. A student reads the policy from across the room.

```html
<div class="work">
  <div class="work-label mono">The work · 45 minutes</div>
  <span class="aitag off">[ NO AI ] DO THIS ONE YOURSELF</span>
  <p>The task, in plain verbs.</p>
  <p class="why">One sentence on why this one is AI-off, in the voice.</p>
</div>
```

For an AI-on task, swap the marker: `<span class="aitag on">[ AI OK ] USE THE TOOLS</span>` and follow the task with a worked prompt example.

Reading block. The primary-source slot, at the foot of the core track. One canon link per page, the essay from the reading map, with a one-line reason in the voice. The link is a real `<a>`, so the accent on it counts as a text link, not a fifth color. Keep it to a single essay; a page that dumps five links teaches nothing.

```html
<div class="reading">
  <div class="reading-label mono">Reading</div>
  <a href="https://www.ycombinator.com/library/8z-how-to-get-startup-ideas">Paul Graham · How to Get Startup Ideas</a>
  <p class="why">Where ideas actually come from. Read it before Class 02.</p>
</div>
```

Deep dive. Native `<details>`, folded by default, tagged optional, on the same page as its core track. The core track must read as complete without it.

```html
<details class="deepdive">
  <summary>
    <span class="toggle mono" aria-hidden="true"></span>
    <span>Deep dive: the optional depth</span>
    <span class="dd-tag">optional</span>
  </summary>
  <div class="dd-body"><p>The curious student goes further here.</p></div>
</details>
```

Footer. Previous and next, nothing else.

```html
<footer>
  <div class="wrap">
    <a href="../index.html">← Course index</a>
    <a href="../class-02/">Class 02 →</a>
  </div>
</footer>
```

### Accessibility and motion

Cobalt focus-visible outlines stay. Reduced motion is respected in the stylesheet, so do not add page-level animation that ignores it. The page is single-column under 720px, where the class number jumps above the headline. Use real `<details>`, real `<a>`, real heading order. No div-only interactivity.

### HTML check, before you ship a page

- Links `style.css`, defines no tokens inline.
- Class number matches the class and carries `aria-hidden`.
- Accent appears only in the four allowed places.
- Every activity has an AI marker, solid block for off, outline for on.
- The core track carries one reading-block link, the essay from the reading map.
- The `meta ac:tags` line and the visible tag rail agree.
- Deep dive is a `details` block on the same page, not a separate file.
- Opens correctly at 375px wide.

---

## Repo conventions

The site is plain HTML hosted on GitHub Pages. Folder-per-class layout, no build step.

`index.html` at the root is the course landing page. Each class is its own folder, `class-01/` through `class-12/`, holding a single `index.html`, so the public URL is `/class-01/` with no `.html` tail. Pitch days (04, 08, 12) use the same page shape with `type=pitch` in the tags and `PITCH · SHARK TANK` in the kicker, and carry no reading block. `style.css` and `_template.html` sit at the root. A `.nojekyll` file at the root turns Jekyll off so files starting with an underscore are served. Cross-class images live in `assets/` at the root; a worksheet that belongs to one class lives inside that class's own folder.

`class-01/index.html` is the reference render. Treat it as the worked example of the voice and the look. Every page, it included, links the shared `style.css` at the root with `../style.css` and defines no tokens inline, which is what `_template.html` does. Keep them visually identical.

Every class is one page. The activity is not a separate document, it is the reason the page exists, so it lives inline in the work block. If a class needs a printable worksheet, it goes in `assets/` and the page links to it.

Deep-dive content lives on the same page as its core track, inside the `details.deepdive` block. Do not split it into a separate file. The depth is right there, one click down, for the student who wants it.

To make a new page, create a `class-NN/` folder and copy `_template.html` into it as `index.html`, then fill in the number, kicker, headline, tags, meta line, and body, and wire the footer prev/next to `../class-NN/`. Never ship a page with placeholders like NN or the ellipses still in it. Guess the tag values honestly and let a human correct you.
